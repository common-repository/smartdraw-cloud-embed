=== SmartDraw Embed Shortcode ===
Contributors: SmartDraw
Tags: smartdraw, wordpress, embed
Requires at least: 4.0
Tested up to: 4.5.3
Stable tag: 4.4
License: MIT

This plugin allows the embedding of SmartDraw diagrams from SmartDraw Cloud using a simple [smartdraw] shortcode.

== Description ==

This plugin allows the embedding of SmartDraw diagrams from SmartDraw Cloud using a simple [smartdraw] shortcode. 

The embed code for the diagram should be obtained from the Share->Embed dialog in SmartDraw Cloud.  In the dialog under "Embed Format" select "WordPress Shortcode".

The plugin also installs a TinyMCE 4.x plug-in that adds an "Insert SmartDraw Diagram" button to the editor toolbar.  

== Installation ==

Install this plugin like any other.  

1. Go to Admin > Plugins > Add New > Upload.

Manual install:

1. Put it into the `/wordpress/wp-content/plugins/` directory 
2. Activate it in the admin Plugin page.

== Usage ==

Method 1: Embedding using TinyMCE 4.x Visual Editor SmartDraw Toolbar Button:

Get the WordPress embed code from the "Embed" dialog in SmartDraw Cloud, under the "Share" dropdown menu.

The embed code will look something like:

FC31BA77EBD84A4E2B96F701A9ACB2BE424

Click the "Copy" button in the "Embed" dialog.

Open your WordPress page.

Click the "Insert SmartDraw Diagram" button in the editor commands toobar.

Paste in the SmartDraw Share Code you copied, enter an optional caption, and select the toolbar style.

The plug-in will then generate the required WordPress short code and insert it into the page.

Method 2: Directly pasting a full WordPress Short Code into the TinyMCE 4.x Visual Editor

Get the full WordPress short code from the "Embed" dialog in SmartDraw Cloud, under the "Share" dropdown menu.

The full short code will look something like:

[smartdraw embed="doc=FC31BA77EBD84A4E2B96F701A9ACB2BE424&preview=87213&unique=40330&mode=1&caption=Afghanistan Map"]

Click the "Copy" button in the "Embed" dialog.

Open your WordPress page.

Paste the full short code into the TinyMCE visual editor.

== Frequently Asked Questions == 


== Screenshots == 

[none]

== Changelog ==

= 1.0 =
* Initial version

== Upgrade Notice ==

Just copy the new version over the old version.

